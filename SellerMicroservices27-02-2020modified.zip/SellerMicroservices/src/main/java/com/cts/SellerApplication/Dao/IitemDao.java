package com.cts.SellerApplication.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cts.SellerApplication.Entity.Items;
@Repository
public interface IitemDao extends JpaRepository<Items, Integer>{
	
	
	@Query(value = "SELECT * FROM items item WHERE item.seller_id = :sellerId"	,nativeQuery = true)
	Optional<Items> getAllItems(@Param("sellerId")Integer sellerid);
	//@Query(value = "SELECT * FROM items item WHERE item.item_name like ?1%",nativeQuery = true)
	@Query(value="from Items where itemName like %:itemname%")
	List<Items> findByitemName(@Param("itemname") String itemName);

}

package com.cts.SellerApplication.Controller;
import java.util.List;
//import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cts.SellerApplication.Entity.Items;
import com.cts.SellerApplication.Service.ItemService;
@RestController
@RequestMapping("/api")
public class ItemsController {
	@Autowired
	private ItemService itemService;
	@RequestMapping(value = "/seller/additem", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Items item) {
		
		return itemService.createOrUpdate(item);
	}
	@RequestMapping(value = "/seller/{itemId}", method = RequestMethod.DELETE, produces = "application/json")
	public String Deleteitem(@PathVariable(value = "itemId") Integer itemId) {
		itemService.deleteItem(itemId);
		return "item deleted" ;
	}
	@RequestMapping(value="/seller/{Itemid}", method= RequestMethod.PUT, produces = "application/json")
	 public Items updateItem(@RequestBody Items item,@PathVariable("Itemid") Integer itemid)
	 {
		 return itemService.UpdateItem(item, itemid);
	 }	
	 @RequestMapping(value="/seller/{sellerid}", method=RequestMethod.GET, produces="application/json")
		public Optional<Items> getAllItems(@PathVariable("sellerid") Integer sellerid)
		{
			return itemService.getAllItems(sellerid);
		}
	 @PostMapping(value="/seller/{itemname}")
	 
		public List<Items> getByItemName(@PathVariable("itemname") String itemName)
		{
			return itemService.getByItemName(itemName);
		}
}

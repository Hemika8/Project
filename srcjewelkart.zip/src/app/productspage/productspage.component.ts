import { Component, OnInit } from '@angular/core';
import { BuyerService } from '../buyer.service';
import { Items } from '../items';
@Component({
  selector: 'app-productspage',
  templateUrl: './productspage.component.html',
  styleUrls: ['./productspage.component.css']
})
export class ProductspageComponent implements OnInit {
itemname:string;
items:Items[];
  constructor(private buyerservice:BuyerService) { }

  ngOnInit(): void {
    this.itemname="";
  }
  searchitems()
  {
    this.buyerservice.getitemsbyname(this.itemname)
    .subscribe(items=>this.items=items);
    console.log(this.items);
    console.log("i am in");
  }
onClick()
{
  this.itemname="";
  this.searchitems();
}
}

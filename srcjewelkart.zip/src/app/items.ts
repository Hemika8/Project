export class Items {
    itemId:number;
    categoryId:number;
    subcategoryId:number;
    sellerId:number;
    price:number;
    itemName:string;
    description:string;
    stockNumber:number;
    remarks:string;
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './home/home.component';
import {BuyersignupComponent} from './buyersignup/buyersignup.component';
import { ProductspageComponent } from './productspage/productspage.component';
const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'buyersignup',component:BuyersignupComponent},
  {path:'router',component:ProductspageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

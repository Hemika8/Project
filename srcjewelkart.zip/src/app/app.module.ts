import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CartpageComponent } from './cartpage/cartpage.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { HomeComponent } from './home/home.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ProductspageComponent } from './productspage/productspage.component';

@NgModule({
  declarations: [
    AppComponent,
    CartpageComponent,
    BuyersignupComponent,
    HomeComponent,
    BuyerloginComponent,
    ProductspageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

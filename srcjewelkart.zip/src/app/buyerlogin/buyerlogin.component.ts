import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyerlogin',
  templateUrl: './buyerlogin.component.html',
  styleUrls: ['./buyerlogin.component.css']
})
export class BuyerloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

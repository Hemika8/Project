import { Buyer } from './buyer';

describe('Buyer', () => {
  it('should create an instance', () => {
    expect(new Buyer()).toBeTruthy();
  });
});

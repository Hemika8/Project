import { Component, OnInit } from '@angular/core';
import{ Item} from '../item';
import {SellerService} from '../seller.service';
@Component({
  selector: 'app-search-items',
  templateUrl: './search-items.component.html',
  styleUrls: ['./search-items.component.css']
})
export class SearchItemsComponent implements OnInit {
searchstring:string;
items:Item[];
  constructor(private dataService: SellerService) { }

  ngOnInit(): void {
    this.searchstring="";
  }
  private searchitems() {
    this.dataService.getitemsbyproductname(this.searchstring)
      .subscribe(items => this.items = items);
  }
  onSubmit() {
    this.searchitems();
  }
}

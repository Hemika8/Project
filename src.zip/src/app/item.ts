export class Item {
    itemId:number;
    categoryId:Category;
    subcategoryId:SubCategory;
    sellerId:Seller;
    price:number;
    itemName:string;
    description:string;
    stockNumber:number;
    remarks:string;
}

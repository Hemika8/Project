import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Searchoption } from './Searchoptions';
@Injectable({
  providedIn: 'root'
})
export class SellerService {
  private baseUrl = 'http://localhost:8094/api/seller';
  constructor(private http: HttpClient) { }
  getitemsbyproductname(Searchoptions:string): Observable<any>
  {
    return this.http.get(`${this.baseUrl}/${itemName}`);
  }
}

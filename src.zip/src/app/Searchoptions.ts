import { StringifyOptions } from 'querystring';

export class Searchoption {
    searchString: String;
     Manufacturer: String;
      fromPrice: number;
      toPrice:number;
}
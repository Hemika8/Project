import { Component, OnInit } from '@angular/core';
import { Seller } from '../seller';
import { SellerService } from '../seller.service';
@Component({
  selector: 'app-root',
  templateUrl: './sellerlogin.component.html',
  styleUrls: ['./sellerlogin.component.css']
})
export class SellerloginComponent implements OnInit {

  seller: Seller = new Seller();
  submitted = false;

  constructor(private sellerService: SellerService) { }

  ngOnInit() {
  }

  newCustomer(): void {
    this.submitted = false;
    this.seller = new Seller();
  }

  save() {
    this.sellerService.createSeller(this.seller)
      .subscribe(data => console.log(data), error => console.log(error));
    this.seller= new Seller();
  }

  onSubmit() {
    this.submitted = true;
    console.log("hemika");
    this.save();
    console.log("yamuna");
  }
}

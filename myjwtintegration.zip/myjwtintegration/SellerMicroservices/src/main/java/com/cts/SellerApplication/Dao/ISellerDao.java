package com.cts.SellerApplication.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.SellerApplication.Entity.Seller;

@Repository
public interface ISellerDao extends JpaRepository<Seller,Integer> {

}

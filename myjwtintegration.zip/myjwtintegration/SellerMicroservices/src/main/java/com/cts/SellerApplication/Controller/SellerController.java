package com.cts.SellerApplication.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SellerApplication.Entity.Seller;
import com.cts.SellerApplication.Service.SellerService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class SellerController {
	@Autowired
	private SellerService service;
	@RequestMapping(value = "/seller", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Seller seller) {
		return service.createOrUpdate(seller);
	}
}

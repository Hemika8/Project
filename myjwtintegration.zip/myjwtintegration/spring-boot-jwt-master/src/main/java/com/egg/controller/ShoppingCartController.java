package com.egg.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.egg.model.ShoppingCart;
import com.egg.service.ShoppingCartService;
@RestController
@RequestMapping("/api")
@CrossOrigin(origins ="*")
public class ShoppingCartController {
	@Autowired
	private ShoppingCartService shoppingCartService;
	@RequestMapping(value = "/Buyer/{buyerId}/addcartitem", method = RequestMethod.POST, produces = "application/json")
	public ShoppingCart addCartItems(@PathVariable(value = "buyerId") Integer buyerId,@RequestBody ShoppingCart cartItem) {
		Optional<ShoppingCart> savedItem = shoppingCartService.addItemToCart(cartItem, buyerId);
		return savedItem.get();
	}
	@RequestMapping(value = "/deletecartitem/{cartId}", method = RequestMethod.DELETE)
	public String Deletecartitem(@PathVariable(value = "cartId") Integer cartId) {
		shoppingCartService.deleteCartItem(cartId);
		return "item deleted" ;
	}
	@RequestMapping(value = "/{buyerId}/emptycartitems", method = RequestMethod.DELETE)
	public void emptyCartItems(@PathVariable(value = "buyerId") Integer buyerId) {
		shoppingCartService.emptyCartItems(buyerId);
		
	}
	 @RequestMapping(value="/update", method= RequestMethod.PUT, produces = "application/json")
	 public ShoppingCart updateCart(@RequestBody ShoppingCart shoppingcart)
	 {
		 return shoppingCartService.UpdateCart(shoppingcart.getCartId(),shoppingcart);
	 }
	 @RequestMapping(value="/{buyerid}/getall", method=RequestMethod.GET)
		public List<ShoppingCart> getAllCartItems(@PathVariable("buyerid") Integer id)
		{
			return shoppingCartService.getAllCart(id);
		}
	 @PostMapping("/{buyerid}/checkout")
	 public void checkout(@PathVariable("buyerid") Integer buyerid)
	 {
		 shoppingCartService.CheckoutCart(buyerid);
	 }
}

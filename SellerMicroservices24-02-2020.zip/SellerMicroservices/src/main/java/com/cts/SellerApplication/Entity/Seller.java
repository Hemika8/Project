package com.cts.SellerApplication.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Seller {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sellerId; 
	private String sellerName;
	private String password;
	private String companyName;
	private String GSTIN;
	private String briefAboutCompany;
	@OneToOne
	@JoinColumn(name="sellerAddressId")
	private Address postalAddress;
	private String website;
	private String emailId;
	private String contactNumber;
	public Seller()
	{
		
	}
	public Seller(int sellerId, String sellerName, String password, String companyName, String gSTIN,
			String briefAboutCompany, Address postalAddress, String website, String emailId, String contactNumber) {
		this.sellerId = sellerId;
		this.sellerName = sellerName;
		this.password = password;
		this.companyName = companyName;
		GSTIN = gSTIN;
		this.briefAboutCompany = briefAboutCompany;
		this.postalAddress = postalAddress;
		this.website = website;
		this.emailId = emailId;
		this.contactNumber = contactNumber;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getGSTIN() {
		return GSTIN;
	}
	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}
	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}
	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}
	public Address getPostalAddress() {
		return postalAddress;
	}
	public void setPostalAddress(Address postalAddress) {
		this.postalAddress = postalAddress;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	

}

package com.cts.SellerApplication.Controller;
import java.util.List;

//import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cts.SellerApplication.Entity.Items;
import com.cts.SellerApplication.Service.ItemService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class ItemsController {
	@Autowired
	private ItemService itemService;
	@RequestMapping(value = "/seller/additem/{sellerid}", method = RequestMethod.POST, produces = "application/json")
	public Optional<Items> createOrUpdate (@RequestBody Items item,@PathVariable(value="sellerid") Integer sellerId) {
		
		return itemService.createOrUpdate(item,sellerId);
	}
	@RequestMapping(value = "/seller/deleteitem/{itemId}", method = RequestMethod.DELETE)
	public void Deleteitem(@PathVariable(value = "itemId") Integer itemId) {
		itemService.deleteItem(itemId);
		
	}
	@RequestMapping(value="/seller/updateitem", method= RequestMethod.PUT, produces = "application/json")
	 public Items updateItem(@RequestBody Items item)
	 {
		 return itemService.UpdateItem(item.getItemId(),item);
	 }	
	 @RequestMapping(value="/seller/getallitems/{sellerid}", method=RequestMethod.GET)
		public List<Items> getAllItems(@PathVariable("sellerid") Integer sellerid)
		{
			List<Items> items=itemService.getAllItems(sellerid);
			return items;
		}
	 @GetMapping(value="/seller/getbyname/{itemname}")
	 
		public List<Items> getByItemName(@PathVariable("itemname") String itemName)
		{
		 System.out.println(""+itemName);
		 System.out.println(itemService.getByItemName(itemName));
			return itemService.getByItemName(itemName);
		}
}

package com.cts.SellerApplication.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.SellerApplication.Dao.ISellerDao;
import com.cts.SellerApplication.Dao.IitemDao;
import com.cts.SellerApplication.Entity.Items;
@Service
public class ItemService {
	@Autowired
    private IitemDao itemDao;
	@Autowired
	private ISellerDao sellerDao;
	public Optional<Items> createOrUpdate(Items item,Integer sellerid) {
		return sellerDao.findById(sellerid).map(seller -> {
            item.setSellerId(seller);
            return itemDao.save(item);
        });
	}
	public void deleteItem(Integer itemId) {
		itemDao.deleteById(itemId);
			}
	public Items UpdateItem( Integer itemid,Items item) {
		Optional<Items> item1 = itemDao.findById(itemid);
		Items item2=null;
	if(item1.isPresent())
	{
		item2 = item1.get();
		item2.setStockNumber(item.getStockNumber());
		      return itemDao.save(item2);
	}
		return null;
	}
			public List<Items> getAllItems(Integer sellerid) {
			List<Items> items=itemDao.getAllItems(sellerid);
			return items;
		}
			
			
			public List<Items> getByItemName(String itemName) {
				return itemDao.findByitemName(itemName);
			}
		
	}

	



package com.cts.ProjectApplication.BuyerDao;

import java.util.List;

import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.ProjectApplication.Buyer.Buyer;
//import com.cts.ProjectApplication.Buyer.Buyer;
import com.cts.ProjectApplication.Buyer.ShoppingCart;

@Repository
public interface IShoppingCartDao extends JpaRepository<ShoppingCart, Integer> {
	@Transactional
	@Modifying
	@Query(value="DELETE FROM shopping_cart WHERE shopping_cart.buyer_id= :buyerId",nativeQuery=true)
	void deleteBybuyer(@Param("buyerId") Buyer buyer);
	@Query(value = "SELECT * FROM shopping_cart cart WHERE cart.buyer_id = :buyerId",nativeQuery = true)
	List<ShoppingCart> getAllCartItems(@Param("buyerId") Integer buyerid);

	
	

}

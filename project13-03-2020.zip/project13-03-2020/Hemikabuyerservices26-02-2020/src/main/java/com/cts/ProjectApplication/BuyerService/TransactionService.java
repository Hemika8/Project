package com.cts.ProjectApplication.BuyerService;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ProjectApplication.Buyer.Transaction;
import com.cts.ProjectApplication.BuyerDao.IBuyerDao;
import com.cts.ProjectApplication.BuyerDao.ITransactionDao;

@Service
public class TransactionService {
	@Autowired
private IBuyerDao buyerDao;
	@Autowired
	private ITransactionDao transactionDao;
	public Optional<Transaction> createTransaction(int buyerid, @Valid Transaction transaction) {
		return buyerDao.findById(buyerid).map(buyerentity -> {
			transaction.setBuyer(buyerentity);
            return transactionDao.save(transaction);});
		
	}

}

package com.cts.ProjectApplication.Buyer;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedDate;
@Entity
public class Transaction{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;
	@Column(name="transaction_type")
	private String transactionType;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	private Date date_time;
	@Column(name="tran_remarks")
	private String tranRemarks;
	@ManyToOne /* (fetch = FetchType.LAZY, optional = false) */  
	@JoinColumn(name = "buyerId", nullable = false)
	@OnDelete(action = OnDeleteAction.CASCADE)
	  private Buyer buyer;
	
	public Buyer getBuyer() {
		return buyer;
	}

	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}

	public Transaction() {
		
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getDate_time() {
		return date_time;
	}

	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}

	public String getTranRemarks() {
		return tranRemarks;
	}

	public void setTranRemarks(String tranRemarks) {
		this.tranRemarks = tranRemarks;
	}

	public Transaction(int transactionId, String transactionType, Date date_time, String tranRemarks) {
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.date_time = date_time;
		this.tranRemarks = tranRemarks;
	}

	
}

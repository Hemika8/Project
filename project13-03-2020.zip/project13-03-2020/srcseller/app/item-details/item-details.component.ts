import { Component, OnInit } from '@angular/core';
import { Item } from '../item';
import { SellerService } from '../seller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
item:Item=new Item();
itemId:any;
  constructor(private sellerService: SellerService,private route:Router) { }

  ngOnInit(): void {
  }
  save() {
    this.sellerService.additem(this.item)
      .subscribe(itemId => this.itemId = itemId);
    this.item= new Item();
    this.route.navigate(['displayitems'])
  }
  additem() {
    console.log
       this.save();
     }
}

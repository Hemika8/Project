import { Component, OnInit } from '@angular/core';
import { SellerService } from '../seller.service';
import { Item } from '../item';

@Component({
  selector: 'app-displayitems',
  templateUrl: './displayitems.component.html',
  styleUrls: ['./displayitems.component.css']
})
export class DisplayitemsComponent implements OnInit {

  constructor(private sellerservice:SellerService) { }
items:Item[];
  ngOnInit(): void {
this.sellerservice.getitems().subscribe(items=>this.items=items);
  }
  reloadItems()
  {
    this.sellerservice.getitems().subscribe(items => 
      {console.log("markk"+JSON.stringify(items)); this.items=items;});
  }
  deleteitem(id:number)
  {
    this.sellerservice.deleteitem(id).subscribe(()=>this.reloadItems());
  }
  increment(items:Item)
  {
    items.stockNumber=items.stockNumber+1;
    this.sellerservice.updatestocknumber(items).subscribe(stockNumber=>this.items=stockNumber);
  }
  decrement(items:Item)
  {
    items.stockNumber=items.stockNumber-1;
    this.sellerservice.updatestocknumber(items).subscribe(stockNumber=>this.items=stockNumber);
  }
}

import { Component, OnInit } from '@angular/core';
import { SellerService } from '../seller.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sellersignin',
  templateUrl: './sellersignin.component.html',
  styleUrls: ['./sellersignin.component.css']
})
export class SellersigninComponent implements OnInit {
  loginForm: FormGroup;
  invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router, private apiService: SellerService) { }
  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }
    const loginPayload = {
      username: this.loginForm.controls.username.value,
      password: this.loginForm.controls.password.value
    }
    this.apiService.login(loginPayload).subscribe(data => {
      debugger;
      if(data.status === 200) {
        window.localStorage.setItem('token', data.result.token);
        window.localStorage.setItem('username',data.result.username);
        window.localStorage.setItem('Id',data.result.sellerId);
        this.router.navigate(['displayitem']);
      }else {
        this.invalidLogin = true;
        alert(data.message);
      }
    });
  }
  ngOnInit(): void {
    window.localStorage.removeItem('token');
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.compose([Validators.required])],
      password: ['', Validators.required]
    });
  }

}

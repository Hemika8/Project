import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { DisplayitemsComponent } from './displayitems/displayitems.component';
import { HomeComponent } from './home/home.component';
import { SellersigninComponent } from './sellersignin/sellersignin.component';
import { LogoutComponent } from './logout/logout.component';


const routes: Routes = [ { path: 'sellersignup', component: SellersignupComponent },
{path:'additem', component:ItemDetailsComponent},
{path: 'sellersignin', component:SellersigninComponent},
{path:'displayitem', component:DisplayitemsComponent},
{path:'',component:HomeComponent},
{path:'logout',component:LogoutComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]

})
export class AppRoutingModule { }

package com.egg.model;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class SubCategory{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int subcategoryId;
	private String subcategoryName;
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category categoryId;
	private String briefDetails;
	public SubCategory() {
		
	}
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}
	public Category getCategoryId() {
		return categoryId;
	}
	public void setCategoryId( Category categoryId) {
		this.categoryId = categoryId;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	@Override
	public String toString() {
		return "SubCategory [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+ ",categoryId=" + categoryId + ", briefDetails=" + briefDetails + "]";
	}


}

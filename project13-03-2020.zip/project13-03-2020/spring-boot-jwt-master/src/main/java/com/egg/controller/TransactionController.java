package com.egg.controller;

import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.Transaction;
import com.egg.service.TransactionService;
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class TransactionController {
	@Autowired
	  private TransactionService transactionService;
	  @RequestMapping("/Buyer/{buyerId}/Transaction")
	  public Optional<Transaction> createTransaction(@PathVariable (value = "buyerId") int buyerid,
            @Valid @RequestBody Transaction transaction )
	  {
		  
		  return transactionService.createTransaction(buyerid, transaction);
	  }

}

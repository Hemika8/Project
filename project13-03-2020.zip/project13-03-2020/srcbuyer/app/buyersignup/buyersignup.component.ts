import { Component, OnInit } from '@angular/core';
import { Buyer} from '../buyer';
import { BuyerService } from '../buyer.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-buyersignup',
  templateUrl: './buyersignup.component.html',
  styleUrls: ['./buyersignup.component.css']
})
export class BuyersignupComponent implements OnInit {
  buyer: Buyer =new Buyer();
  buyerId : any;
  constructor(private buyerservice:BuyerService,private router:Router) { }

  ngOnInit(): void {
  }
  save()
  {
   this.buyerservice.addbuyer(this.buyer)
   .subscribe(buyerId => this.buyerId = buyerId);
   this.router.navigate(['buyerlogin']);
  }
onSubmit()
{
  this.save();
}
}

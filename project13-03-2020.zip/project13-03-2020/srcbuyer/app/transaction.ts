export class Transaction {
    transactionType:string;
    tranRemarks:string;
}

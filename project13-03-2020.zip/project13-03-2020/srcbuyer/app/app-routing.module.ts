import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './home/home.component';
import {BuyersignupComponent} from './buyersignup/buyersignup.component';
import { AppComponent } from './app.component';
import { ProductpageComponent } from './productpage/productpage.component';
import { CartpageComponent } from './cartpage/cartpage.component';
import { TransactionComponent } from './transaction/transaction.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'buyersignup',component:BuyersignupComponent},
  {path: 'app' , component:AppComponent},
  {path: 'productpage', component:ProductpageComponent},
  {path: 'cartpage',component:CartpageComponent},
  {path:'transaction',component:TransactionComponent},
  {path:'buyerlogin',component:BuyerloginComponent},
  {path:'logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

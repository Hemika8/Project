import { Component } from '@angular/core';
import { Items } from './items';
import { BuyerService } from './buyer.service';
//import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'jewelkart';
  itemname:string;
item1:Items[];
  constructor(private buyerservice:BuyerService/*,private route:Router*/) { }

  ngOnInit(): void {
   }
  searchitems()
  {
    this.buyerservice.getitemsbyname(this.itemname)
    .subscribe(items=>this.item1=items);
   // this.route.navigate(['productpage']);
      }
onClick()
{
  this.searchitems();
}
}

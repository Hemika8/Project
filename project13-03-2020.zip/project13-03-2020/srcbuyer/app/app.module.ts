import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CartpageComponent } from './cartpage/cartpage.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { HomeComponent } from './home/home.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ProductpageComponent } from './productpage/productpage.component';
import { TransactionComponent } from './transaction/transaction.component';
import { BuyerService } from './buyer.service';
import { TokenInterceptor } from './interceptor';
import { LogoutComponent } from './logout/logout.component';
@NgModule({
  declarations: [
    AppComponent,
    CartpageComponent,
    BuyersignupComponent,
    HomeComponent,
    BuyerloginComponent,
    ProductpageComponent,
    TransactionComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [BuyerService, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }

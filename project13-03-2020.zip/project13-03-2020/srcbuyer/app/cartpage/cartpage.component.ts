import { Component, OnInit } from '@angular/core';
import { BuyerService } from '../buyer.service';
import { displaycart } from '../items';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cartpage',
  templateUrl: './cartpage.component.html',
  styleUrls: ['./cartpage.component.css']
})
export class CartpageComponent implements OnInit {
  cart:displaycart[];
  constructor(private buyerservice:BuyerService,private transaction:Router) { }
  cost:number;
  ngOnInit(): void {
    this.buyerservice.getcartitems().subscribe(cart=>this.cart=cart);
  }
  increment(cart:displaycart)
  {
    cart.quantity=cart.quantity+1;
    if(cart.quantity!=1)
    {
      cart.totalprice=cart.quantity*this.cost;
      this.buyerservice.updatequantity(cart).subscribe(quantity=>this.cart=quantity);
    }
  }
   decrement(cart:displaycart)
  {
    cart.quantity=cart.quantity-1;
    if(cart.quantity!=1)
    {
      cart.totalprice=cart.quantity*this.cost;
      this.buyerservice.updatequantity(cart).subscribe(quantity=>this.cart=quantity);
    }
  } 
   reloadcartItems()
   {
    this.buyerservice.getcartitems().subscribe( cart => 
      {console.log("markk"+JSON.stringify(cart)); this.cart=cart;});
    }
deletecartitem(id:number)
{
this.buyerservice.deleteitem(id).subscribe(()=>this.reloadcartItems());
}
checkout(){
this.transaction.navigateByUrl('transaction');
}
}

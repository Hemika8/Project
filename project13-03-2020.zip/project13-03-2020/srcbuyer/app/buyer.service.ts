import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { $ } from 'protractor';
import { Transaction } from './transaction';
import { ApiResponse } from './apiresponse';
import { displaycart } from './items';

@Injectable({
  providedIn: 'root'
})
export class BuyerService {
bid:string=localStorage.getItem('Id');
  constructor(private http: HttpClient) { }
  addbuyer(buyer: Object): Observable<any> {
    return this.http.post(`http://localhost:8113/api/buyer`,buyer);
  }
  getitemsbyname(itemName:string):Observable<any>
  {
    return this.http.get(`http://localhost:8078/api/seller/getbyname/${itemName}`);
  }
  getitems():Observable<any>
{
  return this.http.get(`http://localhost:8078/api/seller/getallitems/1`)
}
addtocart(cart:Object,bid:String):Observable<any>
{
  return this.http.post(`http://localhost:8113/api/Buyer/${bid}/addcartitem`,cart)
}
getcartitems():Observable<any>
{
  return this.http.get(`http://localhost:8113/api/Buyer/${this.bid}/getall`)
}
updatequantity(quantity:displaycart):Observable<any>
{
  return this.http.put(`http://localhost:8113/api/Buyer/update`,quantity)
}

private baseUrl3="http://localhost:8113/api/Buyer/deletecartitem"
deleteitem(id:number):Observable<any>
{
  return this.http.delete(`${this.baseUrl3}/${id}`);
}
checkOutcart(transaction:Transaction):Observable<any>
{
  return this.http.post(`http://localhost:8113/api/Buyer/1/checkout`,transaction);
}
login(loginPayload) : Observable<ApiResponse> {
  return this.http.post<ApiResponse>('http://localhost:8113/' + 'token/generate-token', loginPayload);
}
}

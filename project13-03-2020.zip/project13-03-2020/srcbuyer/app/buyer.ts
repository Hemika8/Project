export class Buyer {
    buyerId:number;
    userName:String;
    password:String;
    email:String;
    mobileNumber:String;
    address:String;
}

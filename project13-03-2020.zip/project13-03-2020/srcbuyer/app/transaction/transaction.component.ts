import { Component, OnInit } from '@angular/core';
import { Transaction } from '../transaction';
import { BuyerService } from '../buyer.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  constructor(private transactionservice:BuyerService,private route:Router) { }

transaction:Transaction;
transactionType:string;
tranRemarks:string;
  ngOnInit(): void {
  }
checkout()
{
  this.transaction=new Transaction();
   this.transaction.transactionType=this.transactionType;
  this.transaction.tranRemarks=this.tranRemarks;
 this.transactionservice.checkOutcart(this.transaction).subscribe(view => this.transaction=view);
 this.route.navigate(['productpage']);
 }
}


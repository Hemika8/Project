import { Component, OnInit, Input } from '@angular/core';
import { Items, Cart } from '../items';
import { BuyerService } from '../buyer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {

  constructor(private buyerservice:BuyerService,private route:Router) { }
 items:Items[];
cart:Cart=new Cart();
cartId:any;
bid:string=localStorage.getItem('Id');
  ngOnInit(): void {
this.buyerservice.getitems().subscribe(items=>this.items=items)
  }
addToCart(itemId:number,price:number)
{
this.cart.itemId=itemId;
this.cart.price=price;
this.cart.quantity=1;
this.buyerservice.addtocart(this.cart,this.bid).subscribe(cartid=>this.cartId=cartid);
this.route.navigate(['cartpage']);
}
}

package com.cts.BuyerInterfaceservice;

//import java.util.List;

import com.cts.Buyer.Buyer;

public interface IBuyerService {

//	List<Buyer> getAllB();

	Integer createOrUpdate(Buyer buyer);

	void deleteById(Integer buyerId);

	Buyer update(Buyer buyer);
    
	Buyer getBuyerById(Integer id);

	Buyer getBuyerByName(String name);

	

}

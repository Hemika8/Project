package com.cts.Seller;

//import java.io.Serializable;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.cts.Buyer.Transaction;

@Entity
public class Items{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category categorId;
	@ManyToOne
	@JoinColumn(name = "subcategoryId")
	private SubCategory subcategoryId;
	@OneToMany
	private Transaction transactionId;
	private float price;
	private String itemName;
	private String description;
	private int stockNumber;
	private String remarks;
	
	
	public Items() {
	
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public Category getCategorId() {
		return categorId;
	}

	public void setCategorId(Category categorId) {
		this.categorId = categorId;
	}

	public SubCategory getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(SubCategory subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getStockNumber() {
		return stockNumber;
	}

	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Items(int itemId, Category categorId, SubCategory subcategoryId, float price, String itemName, String description,
			int stockNumber, String remarks) {
		super();
		this.itemId = itemId;
		this.categorId = categorId;
		this.subcategoryId = subcategoryId;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", categorId=" + categorId + ", subcategoryId=" + subcategoryId
				+ ", price=" + price + ", itemName=" + itemName + ", description=" + description + ", stockNumber="
				+ stockNumber + ", remarks=" + remarks + "]";
	}

	
}

export class Seller {
     sellerName:string;
	 password:string;
     companyName:string;
	 GSTIN:string;
	 briefAboutCompany:string;
     website:string;
	 emailId:string;
	 contactNumber:number;
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import{ Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class SellerService {
  private baseUrl = 'http://localhost:8094/api/seller';

  //http://localhost:8094/api/seller/tv

  constructor(private http: HttpClient) { }
  getitemsbyproductname(searchstring:string): Observable<any>
  {
    
    return this.http.post(`${this.baseUrl}/${searchstring}`,'');
  }
  
  createSeller(seller: Object): Observable<Object> {
    console.log("hemika");
    return this.http.post(`${this.baseUrl}`, seller);
  }

}

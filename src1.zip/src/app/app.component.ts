import { Component } from '@angular/core';
import {SellerService }from './seller.service';
import {Item} from './item';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'jewelkartproject';
  searchstring:string;
  items:Item[];
  
  constructor(private dataService: SellerService) { }

  
  ngOnInit(): void {
    this.searchstring="television";
  }

  private searchitems() {
    this.dataService.getitemsbyproductname(this.searchstring)
      .subscribe(itemslist => this.items = itemslist);
  }
  met() {
    this.searchitems();
  }
}

package com.cts.ProjectApplication.BuyerService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ProjectApplication.Buyer.Transaction;
import com.cts.ProjectApplication.BuyerDao.IBuyerDao;
import com.cts.ProjectApplication.BuyerDao.ITransactionDao;

@Service
public class TransactionService {

	public void addTransaction(Transaction transactionHistory, Integer buyerId) {
		// TODO Auto-generated method stub
		
	}
}

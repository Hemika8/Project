import { Component, OnInit } from '@angular/core';
import { Seller } from '../seller';
import { SellerService } from '../seller.service';

@Component({
  selector: 'app-sellersignup',
  templateUrl: './sellersignup.component.html',
  styleUrls: ['./sellersignup.component.css']
})
export class SellersignupComponent implements OnInit {
  seller: Seller = new Seller();
  sellerId:any;
  constructor(private sellerService: SellerService) { }

  ngOnInit(): void {
  }
  save() {
    this.sellerService.createSeller(this.seller)
      .subscribe(sellerId => this.sellerId = sellerId);
    this.seller= new Seller();
  }
  onSubmit() {
       this.save();
     }
}

export class Seller {
	sellerId:number;
     sellerName:string;
	 password:string;
     companyName:string;
	 gstin:string;
	 briefAboutCompany:string;
     website:string;
	 emailId:string;
	 address:string;
	 contactNumber:number;
}

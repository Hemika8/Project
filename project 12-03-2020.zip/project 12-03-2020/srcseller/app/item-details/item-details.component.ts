import { Component, OnInit } from '@angular/core';
import { Item } from '../item';
import { SellerService } from '../seller.service';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
item:Item=new Item();
itemId:any;
  constructor(private sellerService: SellerService) { }

  ngOnInit(): void {
  }
  save() {
    this.sellerService.additem(this.item)
      .subscribe(itemId => this.itemId = itemId);
    this.item= new Item();
  }
  additem() {
    console.log
       this.save();
     }
}

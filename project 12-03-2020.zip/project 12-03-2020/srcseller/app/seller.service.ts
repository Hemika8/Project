import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import{ Observable } from 'rxjs';
import { Item } from './item';
import { ApiResponse } from './apiresponse';
@Injectable({
  providedIn: 'root'
})
export class SellerService {
  private baseUrl = 'http://localhost:8094/api/seller';

  //http://localhost:8094/api/seller/tv

  constructor(private http: HttpClient) { }
  getitemsbyproductname(searchstring:string): Observable<any>
  {
    
    return this.http.post(`${this.baseUrl}/${searchstring}`,'');
  }
  
  createSeller(seller: Object): Observable<Object> {
    console.log("hemika");
    return this.http.post(`${this.baseUrl}`, seller);
  }
  additem(item:Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}/additem/1`,item);
  }
getitems():Observable<any>
{
  return this.http.get(`${this.baseUrl}/getallitems/1`);
}
deleteitem(id:number):Observable<any>
{
  return this.http.delete(`${this.baseUrl}/deleteitem/${id}`);
}
updatestocknumber(stockNumber:Item):Observable<any>
{
  return this.http.put(`${this.baseUrl}/updateitem`,stockNumber)
}
login(loginPayload) : Observable<ApiResponse> {
  return this.http.post<ApiResponse>('http://localhost:8078/' + 'token/generate-token', loginPayload);
}
}

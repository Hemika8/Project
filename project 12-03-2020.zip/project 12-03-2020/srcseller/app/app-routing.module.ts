import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { DisplayitemsComponent } from './displayitems/displayitems.component';


const routes: Routes = [ { path: 'signup', component: SellersignupComponent },
{path:'additem', component:ItemDetailsComponent},
{path:'displayitem', component:DisplayitemsComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]

})
export class AppRoutingModule { }

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component'; 
import {FormsModule, ReactiveFormsModule, FormGroup} from '@angular/forms';
import { DisplayitemsComponent } from './displayitems/displayitems.component';
import { SellersigninComponent } from './sellersignin/sellersignin.component';
import { SellerService } from './seller.service';
import { TokenInterceptor } from './interceptor';
@NgModule({
  declarations: [
    AppComponent,
    ItemDetailsComponent,
    SellersignupComponent,
    DisplayitemsComponent,
    SellersigninComponent
   
     ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
     ],
  providers: [SellerService, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
 
})
export class AppModule { }

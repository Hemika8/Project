package com.egg.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.Buyer;
import com.egg.service.BuyerService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins ="*")
public class Buyercontroller {

	@Autowired
	private BuyerService service;
	@RequestMapping(value = "/buyer", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Buyer buyer) {
		
		return service.createOrUpdate(buyer);
	}

}

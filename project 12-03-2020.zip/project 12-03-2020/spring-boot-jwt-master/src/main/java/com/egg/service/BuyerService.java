package com.egg.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.egg.dao.IBuyerDao;
import com.egg.model.Buyer;
@Service(value = "userService")
public class BuyerService implements UserDetailsService {
	@Autowired
	private IBuyerDao dao;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Buyer buyer = dao.findByuserName(username);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getUserName(), buyer.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	public Integer createOrUpdate(Buyer buyer) {
		 buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		Buyer buyer1 =(Buyer)dao.save(buyer);
		return buyer1.getBuyerId();
	}
	public Buyer findOne(String username) {
		return dao.findByuserName(username);
	}
	}

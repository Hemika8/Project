package com.egg.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.IBuyerDao;
import com.egg.dao.ITransactionDao;
import com.egg.model.Transaction;
@Service
public class TransactionService {
	@Autowired
private IBuyerDao buyerDao;
	@Autowired
	private ITransactionDao transactionDao;
	public Optional<Transaction> createTransaction(int buyerid, @Valid Transaction transaction) {
		return buyerDao.findById(buyerid).map(buyerentity -> {
			transaction.setBuyer(buyerentity);
            return transactionDao.save(transaction);});
		
	}

}

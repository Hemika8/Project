import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { $ } from 'protractor';
import { displaycart } from './items';
import { Transaction } from './transaction';
import { ApiResponse } from './apiresponse';

@Injectable({
  providedIn: 'root'
})
export class BuyerService {

  constructor(private http: HttpClient) { }
  addbuyer(buyer: Object): Observable<any> {
    return this.http.post(`http://localhost:8200/api/buyer`,buyer);
  }
  getitemsbyname(itemName:string):Observable<any>
  {
    return this.http.get(`http://localhost:8094/api/seller/getbyname/${itemName}`);
  }
  getitems():Observable<any>
{
  return this.http.get(`http://localhost:8094/api/seller/getallitems/1`)
}
addtocart(cart:Object):Observable<any>
{
  return this.http.post(`http://localhost:8200/api/Buyer/1/addcartitem`,cart)
}
getcartitems():Observable<any>
{
  return this.http.get(`http://localhost:8200/api/1/getall`)
}
updatequantity(quantity:displaycart):Observable<any>
{
  return this.http.put(`http://localhost:8200/api/update`,quantity)
}

private baseUrl3="http://localhost:8200/api/deletecartitem"
deleteitem(id:number):Observable<any>
{
  return this.http.delete(`${this.baseUrl3}/${id}`);
}
checkOutcart(transaction:Transaction):Observable<any>
{
  return this.http.post(`http://localhost:8200/api/1/checkout`,transaction);
}
login(loginPayload) : Observable<ApiResponse> {
  return this.http.post<ApiResponse>('http://localhost:8113/' + 'token/generate-token', loginPayload);
}
}

import { Component, OnInit, Input } from '@angular/core';
import { Items, Cart } from '../items';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {

  constructor(private buyerservice:BuyerService) { }
 items:Items[];
cart:Cart=new Cart();
cartId:any;
  ngOnInit(): void {
this.buyerservice.getitems().subscribe(items=>this.items=items)
  }
addToCart(itemId:number,price:number)
{
this.cart.itemId=itemId;
this.cart.price=price;
this.cart.quantity=1;
this.buyerservice.addtocart(this.cart).subscribe(cartid=>this.cartId=cartid);
}
}

import { Component, OnInit } from '@angular/core';
import { Transaction } from '../transaction';
import { BuyerService } from '../buyer.service';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  constructor(private transactionservice:BuyerService) { }

transaction:Transaction;
transactionType:string;
tranRemarks:string;
  ngOnInit(): void {
  }
checkout()
{
  this.transaction=new Transaction();
  console.log(this.transactionType);
  this.transaction.transactionType=this.transactionType;
  this.transaction.tranRemarks=this.tranRemarks;
 this.transactionservice.checkOutcart(this.transaction).subscribe(view => this.transaction=view);
 }
}


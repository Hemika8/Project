package com.egg.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.Items;

@Repository
public interface IitemDao extends JpaRepository<Items, Integer>{
	@Transactional
	@Modifying
	@Query(value = "SELECT * FROM items item WHERE item.sellerid = :sellerId"	,nativeQuery = true)
	List<Items> getAllItems(@Param("sellerId")Integer sellerid);
	//@Query(value = "SELECT * FROM items item WHERE item.item_name like ?1%",nativeQuery = true)
	@Query(value="from Items where itemName like %:itemname%")
	List<Items> findByitemName(@Param("itemname") String itemName);

}

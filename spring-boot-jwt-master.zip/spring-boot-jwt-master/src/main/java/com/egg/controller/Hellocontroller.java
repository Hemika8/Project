package com.egg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.egg.model.ApiResponse;
import com.egg.model.User;
import com.egg.model.UserDto;
import com.egg.service.UserService;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/hello")
public class Hellocontroller {

@GetMapping
public String sayHello()
{
	return "i am hemika";
}

}

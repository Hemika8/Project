package com.cts.ProjectApplication.Buyercontroller;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ProjectApplication.Buyer.ShoppingCart;
import com.cts.ProjectApplication.BuyerService.ShoppingCartService;

@RestController
public class ShoppingCartController {
	@Autowired
	private ShoppingCartService shoppingCartService;
	@RequestMapping(value = "Buyer/{buyerId}/addcartitem", method = RequestMethod.POST, produces = "application/json")
	public ShoppingCart addCartItems(@PathVariable(value = "buyerId") Integer buyerId,@RequestBody ShoppingCart cartItem) {
		Optional<ShoppingCart> savedItem = shoppingCartService.addItemToCart(cartItem, buyerId);
		return savedItem.get();
	}
	@RequestMapping(value = "{cartId}/deletecartitem", method = RequestMethod.DELETE, produces = "application/json")
	public String Deletecartitem(@PathVariable(value = "cartId") Integer cartId) {
		shoppingCartService.deleteCartItem(cartId);
		return "item deleted" ;
	}
	@RequestMapping(value = "{buyerId}/emptycartitems", method = RequestMethod.DELETE, produces = "application/json")
	public String emptyCartItems(@PathVariable(value = "buyerId") Integer buyerId) {
		shoppingCartService.emptyCartItems(buyerId);
		return "item deleted" ;
	}
	 @RequestMapping(value="{CartItemid}/update", method= RequestMethod.PUT, produces = "application/json")
	 public ShoppingCart updateCart(@RequestBody ShoppingCart shoppingcart,@PathVariable("CartItemid") Integer id)
	 {
		 return shoppingCartService.UpdateCart(shoppingcart, id);
	 }
	 @RequestMapping(value="/{buyerid}/getall", method=RequestMethod.GET, produces="application/json")
		public List<ShoppingCart> getAllCartItems(@PathVariable("buyerid") Integer id)
		{
			return shoppingCartService.getAllCart(id);
		}
	 @RequestMapping("/{buyerid}/checkout")
	 public void checkout(@PathVariable("buyerid") Integer buyerid)
	 {
		 shoppingCartService.CheckoutCart(buyerid);
	 }
}

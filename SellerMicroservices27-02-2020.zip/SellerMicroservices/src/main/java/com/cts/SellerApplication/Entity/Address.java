package com.cts.SellerApplication.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Address {
@Id
@GeneratedValue(strategy =GenerationType.IDENTITY)
private int sellerAddressId;
private String plotNo;
private String streetName;
private String landmark;
private String  City;
private String district;
private String state;
private String pincode;
public Address()
{
	
}
public Address(int sellerAddressId, String plotNo, String streetName, String landmark, String city, String district,
		String state, String pincode) {
	this.sellerAddressId = sellerAddressId;
	this.plotNo = plotNo;
	this.streetName = streetName;
	this.landmark = landmark;
	City = city;
	this.district = district;
	this.state = state;
	this.pincode = pincode;
}
public int getSellerAddressId() {
	return sellerAddressId;
}
public void setSellerAddressId(int sellerAddressId) {
	this.sellerAddressId = sellerAddressId;
}
public String getPlotNo() {
	return plotNo;
}
public void setPlotNo(String plotNo) {
	this.plotNo = plotNo;
}
public String getStreetName() {
	return streetName;
}
public void setStreetName(String streetName) {
	this.streetName = streetName;
}
public String getLandmark() {
	return landmark;
}
public void setLandmark(String landmark) {
	this.landmark = landmark;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public String getDistrict() {
	return district;
}
public void setDistrict(String district) {
	this.district = district;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getPincode() {
	return pincode;
}
public void setPincode(String pincode) {
	this.pincode = pincode;
}


}

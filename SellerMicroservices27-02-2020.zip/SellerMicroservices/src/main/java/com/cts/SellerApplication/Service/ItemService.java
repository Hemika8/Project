package com.cts.SellerApplication.Service;
//import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import com.cts.SellerApplication.Dao.IitemDao;
import com.cts.SellerApplication.Entity.Items;
@Service
public class ItemService {
	@Autowired
private IitemDao itemDao;
	public Integer createOrUpdate(Items item) {
		Items item1 =(Items)itemDao.save(item);
		return item1.getItemId();
	}
	public String deleteItem(Integer itemId) {
		itemDao.deleteById(itemId);
		return "Deleted";
		
	}
	public Items UpdateItem(Items item, Integer itemid) {
		Optional<Items> item1 = itemDao.findById(itemid);
		Items item2=null;
	if(item1.isPresent())
	{
		item2 = item1.get();
		item2.setStockNumber(item.getStockNumber());
		      return itemDao.save(item2);
	}
		return null;
	}
			public Optional<Items> getAllItems(Integer sellerid) {
			return itemDao.getAllItems(sellerid);
		}
			public Optional<Items> getByProductName(String itemName) {
				return itemDao.findByProductName(itemName);
			}
		
	}

	



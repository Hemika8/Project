package com.cts.SellerApplication.Entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Items{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category categoryId;
	@ManyToOne
	@JoinColumn(name = "subcategoryId")
	private SubCategory subcategoryId;
	@ManyToOne
	@JoinColumn(name="sellerId")
	private Seller seller_Id;
	private float price;
	private String itemName;
	private String description;
	private int stockNumber;
	private String remarks;
	public Items() {
	
	}
	
	public Seller getSellerId() {
		return seller_Id;
	}

	public void setSellerId(Seller sellerId) {
		this.seller_Id = sellerId;
	}

	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public Category getCategorId() {
		return categoryId;
	}
	public void setCategorId(Category categoryId) {
		this.categoryId = categoryId;
	}
	public SubCategory getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(SubCategory subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Items(int itemId, Category categorId, SubCategory subcategoryId, Seller sellerId, float price,
			String itemName, String description, int stockNumber, String remarks) {
		super();
		this.itemId = itemId;
		this.categoryId = categoryId;
		this.subcategoryId = subcategoryId;
		this.seller_Id = sellerId;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
	}

}

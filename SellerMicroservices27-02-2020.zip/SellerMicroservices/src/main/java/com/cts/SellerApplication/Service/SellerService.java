package com.cts.SellerApplication.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.SellerApplication.Dao.ISellerDao;
import com.cts.SellerApplication.Entity.Seller;

@Service
public class SellerService {
	@Autowired
	private ISellerDao dao;
	public Integer createOrUpdate(Seller seller) {
		Seller seller1 =(Seller)dao.save(seller);
		return seller1.getSellerId();
	}

}
